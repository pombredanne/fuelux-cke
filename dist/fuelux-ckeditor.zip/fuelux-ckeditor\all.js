
/*
 * Fuel UX CKeditor - All Bundle
 * https://github.com/ExactTarget/fuelux-ckeditor
 *
 * Copyright (c) 2012 ExactTarget
 */

define('fuelux-ckeditor/all',['require','http://dl.dropbox.com/u/12146987/ckeditor4/ckeditor'],function (require) {
    /*** Libraries ***/
    /* TODO: ask adam if this is a bad idea */
    require('http://dl.dropbox.com/u/12146987/ckeditor4/ckeditor');
});
