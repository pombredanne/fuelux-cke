
/*
 * Fuel UX CKeditor - All Bundle
 * https://github.com/ExactTarget/fuelux-ckeditor
 *
 * Copyright (c) 2012 ExactTarget
 */

define('fuelux-ckeditor/all',['require'],function (require) {
    /*** Libraries ***/
});
