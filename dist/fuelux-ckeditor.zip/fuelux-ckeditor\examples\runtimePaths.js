require.config({
    paths: {
        'fuelux-ckeditor': './',
        'jquery': '../lib/jquery'
    }
});
