require.config({
    paths: {
        'ckeditor': 'http://dl.dropbox.com/u/12146987/ckeditor4/ckeditor',
        'fuelux-ckeditor': './',
        'jquery': '../lib/jquery'
    }
});
