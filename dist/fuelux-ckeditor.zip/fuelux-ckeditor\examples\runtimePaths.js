require.config({
    paths: {
        'ckeditor': '../lib/ckeditor-dev/dev/builder/release/ckeditor/ckeditor',
        'fuelux-ckeditor': './',
        'jquery': '../lib/jquery'
    }
});
