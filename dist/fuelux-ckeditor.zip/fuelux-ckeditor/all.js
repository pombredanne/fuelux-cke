/*
 * Fuel UX CKeditor - All
 * https://github.com/ExactTarget/fuelux-editor
 *
 * Copyright (c) 2013 ExactTarget
 */

define(['require','fuelux-ckeditor/ckeditor/ckeditor'],function (require) {

    /*** Libraries ***/

    require('fuelux-ckeditor/ckeditor/ckeditor');

    /*** Extensions ***/

});
