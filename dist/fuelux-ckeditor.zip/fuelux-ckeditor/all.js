/*
 * Fuel UX CKeditor - All
 * https://github.com/ExactTarget/fuelux-editor
 *
 * Copyright (c) 2013 ExactTarget
 */

define(['require','fuelux-ckeditor/config'],function (require) {

    require('fuelux-ckeditor/config');

});
