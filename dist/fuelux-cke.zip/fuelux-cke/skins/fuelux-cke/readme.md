"Fuel UX CKE" Skin
====================
